sudo systemctl restart nginx
